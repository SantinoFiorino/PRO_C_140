# PRO_C140_SP_1-4
## conjunto_de_datos_de_productos
Productos: teléfonos inteligentes y celulares, cámaras digitales, audífonos y videojuegos.
